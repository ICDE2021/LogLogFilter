## The basic version of LogLogFilter
