## The fast-update version of LogLogFilter
